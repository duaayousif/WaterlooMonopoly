#ifndef __NONPROPERTY_H__
#define __NONPROPERTY_H__

#include <string>
#include "square.h"

class NonProperty : public Square {

	public:

	//Constructor
	NonProperty();
	//Destructor
	~NonProperty();
	void getAction();

};

#endif
